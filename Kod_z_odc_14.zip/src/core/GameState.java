package core;

import graphics.Screen;

public class GameState {

	public GameState(){
		
	}
	
	public void update(){
		
	}
	
	public void render(Screen s){
		
	}
}
