package game.world.tiles;

import game.world.Tile;

public class Air extends Tile{

	public Air() {
		id = 0;
		colider = false;
		ladder = false;
	}
}
